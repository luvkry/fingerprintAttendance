package com.comscience.fyp.fingerprintattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SuccessActivity extends AppCompatActivity {

    TextView tvDisplayName;
    Button logoutBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);

        Intent intent = getIntent();
        String studentName = intent.getStringExtra("studentName");

        tvDisplayName = findViewById(R.id.tvdisplayName);
        logoutBtn = findViewById(R.id.btnSLogout);

        if (studentName.trim().equals(""))
            tvDisplayName.setText("Hello, User!");
        else
            tvDisplayName.setText("Hello, " + studentName + "!");

        /* Back to Home Page */
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SuccessActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
