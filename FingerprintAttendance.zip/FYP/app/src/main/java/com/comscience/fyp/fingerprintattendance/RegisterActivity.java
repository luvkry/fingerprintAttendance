package com.comscience.fyp.fingerprintattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class RegisterActivity extends AppCompatActivity {

    public static String value = "Register";

    protected Button btnNext, btnCancel;
    protected EditText editName, editContact, editStudentID;
    private static final String KEY_EMPTY = "";

    String register_url = "http://192.168.1.135/fingerprint/register.php";
    JSONParser jsonParser = new JSONParser();

    int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editName = findViewById(R.id.editRStudName);
        editContact = findViewById(R.id.editRStudContact);
        editStudentID = findViewById(R.id.editRStudID);
        btnNext = findViewById(R.id.btnRegNext);
        btnCancel = findViewById(R.id.btnRedBack);

        /* Back to Home Page */
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        /** Register **/
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    RegisterStudent registerStudent = new RegisterStudent();
                    registerStudent.execute(editName.getText().toString(), editContact.getText().toString(), editStudentID.getText().toString());
                }
            }
        });
    }

    private boolean validateInputs() {
        if(KEY_EMPTY.equals(editName.getText().toString())){
            editName.setError("Name cannot be empty");
            editName.requestFocus();
            return false;
        }

        if(KEY_EMPTY.equals(editContact.getText().toString())){
            editContact.setError("Contact cannot be empty");
            editContact.requestFocus();
            return false;
        }

        if(KEY_EMPTY.equals(editStudentID.getText().toString())){
            editStudentID.setError("Student ID cannot be empty");
            editStudentID.requestFocus();
            return false;
        }
        return true;
    }

    private class RegisterStudent extends AsyncTask<String,String, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected JSONObject doInBackground(String... args) {

            String contact = args[2];
            String studentID = args[1];
            String name = args[0];

            ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("name", name));
            params.add(new BasicNameValuePair("studentID", studentID));
            params.add(new BasicNameValuePair("contact", contact));

            JSONObject json = jsonParser.makeHttpRequest(register_url, "POST", params);

            return json;
        }

        @Override
        protected void onPostExecute(JSONObject result) {

            try {
                if (result != null) {
                    String studentName = editName.getText().toString();
                    Intent register = new Intent(RegisterActivity.this, SuccessActivity.class);
                    register.putExtra("studentName", studentName);
                    startActivity(register);
                    Toast.makeText(getApplicationContext(), result.getString("message"), Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
