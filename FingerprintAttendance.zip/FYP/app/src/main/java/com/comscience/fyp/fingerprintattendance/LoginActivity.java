package com.comscience.fyp.fingerprintattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    private static final String KEY_EMPTY = "";
    public static String value;

    private EditText editStudID;
    Button btnBack, btnRequest, btnRegister;
    String login_url = "http://192.168.1.135/fingerprint/login.php";
    //String login_url = "http://172.30.142.252/test-android/login.php";
    JSONParser jsonParser = new JSONParser();

    String errorMessage = "No data", message = "Success";
    String userName;

    Integer userContact, success;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnBack = findViewById(R.id.btnLoginBack);
        btnRequest = findViewById(R.id.btnLoginOTP);
        btnRegister = findViewById(R.id.btnLoginRegister);
        editStudID = findViewById(R.id.editLStudID);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // CHeck if is admin
                value = "Login";
                Intent i = new Intent(LoginActivity.this, ValidationActivity.class);
                startActivity(i);
            }
        });

        btnRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /** Check number from login if is from the database **/
                if (validateInputs()) {
                    GetStudentContact getStudentContact = new GetStudentContact();
                    getStudentContact.execute(editStudID.getText().toString(), "", "");
                }
            }
        });
    }

    private boolean validateInputs() {
        if (KEY_EMPTY.equals(editStudID.getText().toString())) {
            editStudID.setError("Student ID cannot be empty");
            editStudID.requestFocus();
            return false;
        }
        return true;
    }

    private class GetStudentContact extends AsyncTask<String, String, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected JSONObject doInBackground(String... args) {

            String studentID = args[0];

            ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("studentID", studentID));

            JSONObject json = jsonParser.makeHttpRequest(login_url, "GET", params);

            return json;
        }

        @Override
        protected void onPostExecute(JSONObject result) {

            try {
                if (result != null) {
                    if (result.getString("message").equals(errorMessage)) {
                        Toast.makeText(getApplicationContext(), result.getString("message"), Toast.LENGTH_SHORT).show();
                    } else if (result.getString("message").matches(message)) {
                        success = result.getInt("success");
                        if (success == 1) {
                            Intent otpIntent = new Intent(LoginActivity.this, OTPActivity.class);
                            JSONArray student = result.getJSONArray("student");
                            for (int x = 0; x < student.length(); x++) {
                                JSONObject stud = student.getJSONObject(x);
                                userContact = stud.getInt("contact");
                                userName = stud.getString("name");
                                String value = userContact.toString();
                                String studentName = userName;
                                if (!value.isEmpty() && !studentName.isEmpty()) {
                                    otpIntent.putExtra("message", value);
                                    otpIntent.putExtra("studentName",studentName);
                                    startActivity(otpIntent);
                                }
                            }
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Wrong studentID entered", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
