package com.comscience.fyp.fingerprintattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button signIn, signUp;
    public static String value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signIn = findViewById(R.id.btnMainLogin);
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                value = "Login";
                Intent loginIntent = new Intent(MainActivity.this, FingerprintActivity.class);
                startActivity(loginIntent);
            }
        });

        signUp = findViewById(R.id.btnMainRegister);
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                value = "Register";
                Intent registerIntent = new Intent(MainActivity.this, ValidationActivity.class);
                startActivity(registerIntent);
            }
        });
    }

    /*if (editAdminPass.getText().toString().matches(KEY_EMPTY))
                                    Toast.makeText(getApplicationContext(), "Please enter the password", Toast.LENGTH_LONG).show();
                                else {
                                    attemptLogin.execute(editAdminPass.getText().toString(), "", "");
                                }*/

/*    private void Attempt(){
        LayoutInflater inflater = LayoutInflater.from(context);
        View adminPass = inflater.inflate(R.layout.password_layout, null);

        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

        alertDialogBuilder.setView(adminPass);

        //String password = "password";
        final TextView tvAdminPass = findViewById(R.id.tvPass);

        // set dialog message
        alertDialogBuilder
                .setCancelable(false)
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                })
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        AttemptAdminLogin attemptLogin = new AttemptAdminLogin();
                        displayLoader();
                        if(validatePassword())
                            Toast.makeText(getApplicationContext(), "Please enter the password", Toast.LENGTH_LONG).show();
                        else
                            attemptLogin.execute(editAdminPass.getText().toString(),"","");
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        // show it
        alertDialog.show();
    }

    private boolean validatePassword() {
        if(KEY_EMPTY.equals(editAdminPass.getText().toString())){
            editAdminPass.setError("Student ID cannot be empty");
            editAdminPass.requestFocus();
            return false;
        }
        return true;
    }

    private void displayLoader() {
        pDialog = new ProgressDialog(MainActivity.this);
        pDialog.setMessage("Registering Up.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
    }*/


}
