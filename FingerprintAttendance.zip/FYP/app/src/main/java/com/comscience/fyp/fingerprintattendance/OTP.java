package com.comscience.fyp.fingerprintattendance;

import java.util.Random;

public class OTP {
    private Integer userContact;
    private Integer userOneTimePass;
    private Integer generatedOneTimePass;

    // Contact From Database
    protected void setUserContact(Integer contactFound) {
        this.userContact = contactFound;
    }

    // OTP From Input
    protected void setUserOTP(Integer userOTP) {
        this.userOneTimePass = userOTP;
    }

    protected void setGeneratedOTP(){
        Integer value;
        // Using numeric values
        String numbers = "0123456789";

        // Using random method
        Random rndm_method = new Random();
        char[] otp = new char[6];

        for (int i = 0; i < 6; i++)
        {
            // Use of charAt() method : to get character value
            // Use of nextInt() as it is scanning the value as int
            otp[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));
        }
        value = Integer.parseInt(String.valueOf(otp));
        this.generatedOneTimePass = value;
    }


    /*protected void getUserOTP(Integer userOTP){
        this.gOneTimePass = userOTP;
    }*/

    // OTP From Generated
    protected Integer getUserContact(){
        return userContact;
    }

    protected Integer getUserOTP(){
        return userOneTimePass;
    }

    protected Integer getGeneratedOTP(){
        return generatedOneTimePass;
    }
}
