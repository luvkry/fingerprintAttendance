package com.comscience.fyp.fingerprintattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ValidationActivity extends AppCompatActivity {

    EditText editAdminPass;
    Button btnAdminLogin, btnAdminCancel;

    private static final String KEY_EMPTY = "";
    String fromMain_url = "http://192.168.1.135/fingerprint/main.php";
    public static String value;
    JSONParser jsonParser = new JSONParser();

    String errorMessage = "No data";
    String success = "Success";

    MainActivity main = new MainActivity();
    FingerprintActivity fingerprint = new FingerprintActivity();
    String login =  "Login", register="Register";

    String mainValue = main.value;
    String fingerValue = fingerprint.value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validation);

        editAdminPass = findViewById(R.id.editPass);
        btnAdminLogin = findViewById(R.id.btnVLogin);
        btnAdminCancel = findViewById(R.id.btnVCancel);

        btnAdminCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fingerValue.matches(login)){
                    Intent backToLogin = new Intent(ValidationActivity.this, LoginActivity.class);
                    startActivity(backToLogin);
                }
                else if(mainValue.matches(register)){
                    Intent backToMain = new Intent(ValidationActivity.this, MainActivity.class);
                    startActivity(backToMain);
                }
                else{
                    Intent back = new Intent(ValidationActivity.this, MainActivity.class);
                    startActivity(back);
                }
            }
        });

        btnAdminLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validatePassword()){
                    AttemptAdminLogin attemptLogin = new AttemptAdminLogin();
                    attemptLogin.execute(editAdminPass.getText().toString(), "", "");
                }
            }
        });
    }

    private boolean validatePassword() {
        if(KEY_EMPTY.equals(editAdminPass.getText().toString())){
            editAdminPass.setError("Admin Password cannot be empty");
            editAdminPass.requestFocus();
            return false;
        }
        return true;
    }

    private class AttemptAdminLogin extends AsyncTask<String, String, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected JSONObject doInBackground(String... args) {

            String password = args[0];
            JSONObject json;

            ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("password", password));

            json = jsonParser.makeHttpRequest(fromMain_url, "GET", params);

            return json;
        }

        @Override
        protected void onPostExecute(JSONObject result) {

            try {
                if (result != null) {
                    if (result.getString("message").matches(errorMessage)) {
                        Toast.makeText(getApplicationContext(), result.getString("message"), Toast.LENGTH_SHORT).show();
                    } else if (result.getString("message").matches(success)) {
                        Intent registerIntent = new Intent(getApplicationContext(), RegisterActivity.class);
                        startActivity(registerIntent);
                    } else {
                        Toast.makeText(getApplicationContext(), "Wrong password entered", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
