package com.comscience.fyp.fingerprintattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class OTPActivity extends AppCompatActivity {

    private static final String KEY_EMPTY = "";

    Button btnSubmit, btnCancel;
    EditText editOTP;
    TextView tvOTP, tvDisplayStudentName;
    Integer userOTP, genOTP ;
    String userContact, userName;

    OTP getOneTimePassword = new OTP();
    AttemptGetOTP attemptGetOTP = new AttemptGetOTP();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        tvDisplayStudentName = findViewById(R.id.tvStudentName);
        Intent intent = getIntent();
        final String studentName = intent.getStringExtra("studentName");
        userContact = intent.getStringExtra("message");

        if (studentName.trim().equals(""))
            tvDisplayStudentName.setText("Hello, User!");
        else
            tvDisplayStudentName.setText("Hello, " + studentName + "!");

        getOneTimePassword.setGeneratedOTP();
        genOTP = getOneTimePassword.getGeneratedOTP();

        editOTP = findViewById(R.id.editOTP);
        btnSubmit = findViewById(R.id.btnOLogin);
        btnCancel = findViewById(R.id.btnOCancel);
        tvOTP = findViewById(R.id.tvOTP);

        attemptGetOTP.sendOTP(userContact);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent = new Intent(OTPActivity.this, LoginActivity.class);
                startActivity(backIntent);
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validateInputs()){
                    userName = studentName;
                    userOTP = Integer.parseInt(editOTP.getText().toString());
                    attemptGetOTP.compareOTP();
                }
            }
        });
    }

    private boolean validateInputs() {
        if(KEY_EMPTY.equals(editOTP.getText().toString())){
            editOTP.setError("OTP cannot be empty");
            editOTP.requestFocus();
            return false;
        }
        return true;
    }

    private class AttemptGetOTP {

        // Compare User And Generated OTP
        private void compareOTP(){
            if(userOTP.equals(genOTP)){
                if(!userName.isEmpty()){
                    Intent successIntent = new Intent(OTPActivity.this, SuccessActivity.class);
                    successIntent.putExtra("studentName", userName);
                    startActivity(successIntent);
                }
                else{
                    Toast.makeText(OTPActivity.this, "Student Name empty", Toast.LENGTH_SHORT).show();
                }

            } else{
                Toast.makeText(OTPActivity.this, "Please enter the OTP again", Toast.LENGTH_SHORT).show();
            }
        }

        // Send OTP
        private void sendOTP(String contact) {
            try {
                if(genOTP != null){
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(contact, null, "This is your OTP : " + genOTP, null, null);
                    Toast.makeText(getApplicationContext(), "SMS Sent!",
                            Toast.LENGTH_LONG).show();
                } else{
                    Toast.makeText(OTPActivity.this, "OTP not generated", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "SMS failed, please try again later!",
                        Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

        }
    }
}
