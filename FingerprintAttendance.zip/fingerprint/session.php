<?php

require_once 'student.php';
    
    $password = "";
    
    if(isset($_POST['password'])){
        $password = $_POST['password'];
    }

    $studentObject = new Student();
    # Session As Admin
    if(!empty($password)){ 
        $json_array = $studentObject->isLoggedIn($password);
        echo json_encode($json_array);
    }

    # To Access Register Page
    #if(!empty($password)){        
    #    $json_array = $studentObject->isLoginAdmin($password);
    #    echo json_encode($json_array);
    #}


?>