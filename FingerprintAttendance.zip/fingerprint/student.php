<?php
    
    include_once 'db-connect.php';
    
    class Student{
        private $db;        
        private $db_table = "student";
        
        public function __construct(){
            $this->db = new DbConnect();
        }
        
        # Check If Login Exist
        public function isLoginExist($studentID){

            $query = "select * from ".$this->db_table." where studentID = '$studentID' Limit 1";
            $result = mysqli_query($this->db->getDb(), $query);
            if(mysqli_num_rows($result) > 0){
                mysqli_close($this->db->getDb());
            }
            mysqli_close($this->db->getDb());
            return false;
        }   

        # Check If Admin Exist
        public function isAdminExist($password){
            $name = "Admin";
            $query = "select * from ".$this->db_table." where name = '$name' AND password = '$password' Limit 1";
            $result = mysqli_query($this->db->getDb(), $query);
            if(mysqli_num_rows($result) > 0){
                mysqli_close($this->db->getDb());
                return true;
            }
            mysqli_close($this->db->getDb());
            return false;
            
        }  
        
        # Check If Student Exist
        public function isStudentExist($studentID){
            $response = array();
            $query = "select * from ".$this->db_table." where studentID = '$studentID'";
            $result = mysqli_query($this->db->getDb(), $query);
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    $json['success'] = 1;
                    $stud = array();
                    array_push($stud, $row);
                }
                $json['stud'] = $stud;
                mysqli_close($this->db->getDb());
            }
            return $response;
            mysqli_close($this->db->getDb());
        }

        # Register Student
        public function createNewRegisterStudent($name, $contact, $studentID){
            $response = array();
            $isExisting = $this->isStudentExist($studentID);
            if($isExisting){
                $json['success'] = 0;
                $json['message'] = "Error exist";
            }
            else{
                $number = (int)$contact;
                $query = "insert into ".$this->db_table." (name, contact, studentID) values ('$name', '$number','$studentID')";                
                $inserted = mysqli_query($this->db->getDb(), $query);
                
                if($inserted == 1){                    
                    $json['success'] = 1;
                    $json['message'] = "Successfully registered.";                    
                }else{                    
                    $json['success'] = 0;
                    $json['message'] = "Error in registering.";                    
                }                
                mysqli_close($this->db->getDb());
            }
            return $response;
        }
        
        # Get Access To Register Page
        public function loginStudents($studentID){    

            $json = array();            
            $canUserLogin = $this->isAdminExist($password);
            
            if($canUserLogin){                
                $json['success'] = 1;
                $json['message'] = "Successfully logged in";
                
            }else{
                $json['success'] = 0;
                $json['message'] = "Incorrect details";
            }
            return $json;
        }
        

        # Session As Admin
        public function isLoggedIn($password){
            $query = "select * from ".$this->db_table." where name = Admin AND password = '$password' Limit 1";
            if(mysqli_num_rows($result) > 0){
                mysqli_close($this->db->getDb());
                return true;
            }
            mysqli_close($this->db->getDb());
            return false;
        }   

        # Retreive Student
        public function loginStudent($studentID){
            
            $json = array(); 
            $canUserLogin = $this->isLoginExist($studentID);
            
            if($canUserLogin){  
                $json['success'] = 1;
                $json['message'] = "Successfully logged in";
                
            }else{
                $json['success'] = 0;
                $json['message'] = "Incorrect details";
            }
            return $json;
        }

        # Retreive Admin
        public function loginAdmin($password){
            
            $json = array(); 
            $canAdminLogin = $this->isAdminExist($password);
            
            if($canAdminLogin){  
                $json['success'] = 1;
                $json['message'] = "Successfully logged in";
                
            }else{
                $json['success'] = 0;
                $json['message'] = "Incorrect details";
            }
            return $json;
        }

        # Get Student?
        public function getStud($studentID){
           
            $query = "select * from ".$this->db_table." where name = Admin AND name = '$password' Limit 1";
            if(mysqli_num_rows($result) > 0){
                $json['success'] = 1;
                $stud = array();
                while($row = mysqli_fetch_assoc($result)){
                    array_push($stud, $row);
                }
                $json['stud'] = $stud;
                mysqli_close($this->db->getDb());
                return true;
            }
            mysqli_close($this->db->getDb());
            return false;
        }

        # Get Student Name
        public function getStudName($contact){
            $json = array(); 
            $canUserLogin = $this->getStud($studentID);
            if($canUserLogin){  
                $json['success'] = 1;
                $json['message'] = "Successfully logged in";
                
            }else{
                $json['success'] = 0;
                $json['message'] = "Incorrect details";
            }
            return $json;
        }


        # Enter the studentID and send the OTP to the registered number in the database.
        # Add studentID #DONE
        # Remove fingerprint for register #DONE
        # Remove module and year for register #DONE
        # set a password to proceed to register page #DONE not tested
    }
    ?>