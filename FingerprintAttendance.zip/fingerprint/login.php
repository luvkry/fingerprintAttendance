<?php
    
    $db_host = 'localhost';
    $db_user = 'root';
    $db_password = '';
    $db_name = 'fas';

    $conn = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    if(!$conn){
        die("ERROR in connection: ". $mysqli_connect_error());
    }

    $studentID = "";

    if(isset($_GET['studentID'])){
        $studentID = $_GET['studentID'];
    }

    $json = array();
    $query = "select * from student where studentID = '$studentID' Limit 1";
    $result =  mysqli_query($conn, $query);
    if(mysqli_num_rows($result) > 0){
        $json['success'] = 1;
        $json['message'] = "Success";
        $stud = array();
        while($row = mysqli_fetch_assoc($result)){
            array_push($stud, $row);
        }
        $json['student'] = $stud;
    } else{
        $json['success'] = 0;
        $json['message'] = "No data";
    }
    echo json_encode($json);
    mysqli_close($conn);
?>