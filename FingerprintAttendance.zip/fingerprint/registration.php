<?php

require_once 'db-connect.php'

class Register{
    private $db;
    
    private $db_table = "student";
    
    public function __construct(){
        $this->db = new DbConnect();
    }

    
}


# $response['student'] = $stud; 
?>