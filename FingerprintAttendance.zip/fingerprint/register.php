<?php
    require_once 'student.php';
    
    $name = "";
    #$password = "";
    $contact = "";
    $studentID = "";
    
    #lq1439170622
    if(isset($_POST['name'])){
        $name = $_POST['name'];
    }
    
    #if(isset($_POST['password'])){
    #    $password = $_POST['password'];
    #}
    
    if(isset($_POST['studentID'])){
        $studentID = $_POST['studentID'];
    }

    if(isset($_POST['contact'])){
        $contact = $_POST['contact'];
    }

    $studentObject = new Student();
    # Register New Student
    if(!empty($name) && !empty($studentID) && !empty($contact)){               
        $json_registration = $studentObject->createNewRegisterStudent($name, $studentID, $contact);
        echo json_encode($json_registration);
    }

    # Retreive Student
    if(!empty($studentID)){
        $json_array = $studentObject->loginStudent($studentID);
        echo json_encode($json_array);
    }
?>