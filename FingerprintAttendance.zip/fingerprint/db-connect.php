<?php

//these are the server details
//the username is root by default in case of xampp
//password is nothing by default
//and lastly we have the database named android. if your database name is different you have to change it 
#$servername = "localhost";
#$username = "root";
#$password = " ";
#$database = "fas";

include_once 'config-test.php';
    
    class DbConnect{
        
        private $connect;
        
        public function __construct(){
            
            $this->connect = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
            
            if (mysqli_connect_errno($this->connect)){
                echo "Unable to connect to MySQL Database: " . mysqli_connect_error();
            }
        }
        
        public function getDb(){
            return $this->connect;
        }
    }
 
//$conn = new mysqli($servername, $username, $password, $database);
//if ($conn->connect_error) {
//    die("Connection failed: " . $conn->connect_error);
//}
//creating a new connection object using mysqli 
//$conn = new mysqli($servername, $username, $password, $database);
 
//if there is some error connecting to the database
//with die we will stop the further execution by displaying a message causing the error 
//if ($conn->connect_error) {
//    die("Connection failed: " . $conn->connect_error);
//}
    
#    class DbConnect{        
#        private $connect;        
#        public function __construct(){          
#        }       
#        public function getDb(){
#            return $this->connect;
#        }
#    }
    ?>