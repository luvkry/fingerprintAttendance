<?php
    
    require_once 'student.php';

    $password = "";
    
    if(isset($_POST['password'])){
        $password = $_POST['password'];
    }

    $studentObject = new Student();
    # To Access Register Page
    if(!empty($password)){
        $json_array = $studentObject->loginAdmin($password);
        echo json_encode($json_array);
    }


?>