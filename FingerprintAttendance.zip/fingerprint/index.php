<?php
    
    require_once 'student.php';
    
    $name = "";
    $password = "";
    $contact = "";
    $studentID = "";
    
    if(isset($_POST['name'])){
        $name = $_POST['name'];
    }
    
    if(isset($_POST['password'])){
        $password = $_POST['password'];
    }
    
    if(isset($_POST['studentID'])){
        $studentID = $_POST['studentID'];
    }

    if(isset($_POST['contact'])){
        $contact = $_POST['contact'];
    }
    
    #if(isset($_POST['year'])){
    #    $year = $_POST['year'];
    #}

    #if(isset($_POST['module'])){
    #    $module = $_POST['module'];
    #}


    $studentObject = new Student();
    //if(!empty($name) && !empty($password) && !empty($contact)){               
    //   $json_registration = $studentObject->createNewRegisterStudent($name, $password, $contact);
    //    echo json_encode($json_registration);
    //}

    # Register New Student
    if(!empty($name) && !empty($studentID) && !empty($contact)){               
        $json_registration = $studentObject->registerStudent($name, $studentID, $contact);
        echo json_encode($json_registration);
    }
    
    # Login Student
    if(!empty($name) && !empty($contact)){        
        $json_array = $studentObject->loginStudents($studentID, $contact);
        echo json_encode($json_array);
    }

    # Retreive Student
    if(!empty($studentID)){        
        $json_array = $studentObject->getStudent($studentID);
        echo json_encode($json_array);
    }

    # For Register
    if(!empty($password)){        
        $json_array = $studentObject->isLoginAdmin($password);
        echo json_encode($json_array);
    }

    # Session As Admin
    if(!empty($password)){ 
        $json_array = $studentObject->isLoggedIn($password);
        echo json_encode($json_array);
    }
    

    ?>